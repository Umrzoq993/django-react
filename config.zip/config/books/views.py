from rest_framework import generics
from .models import Book
from .serializers import BookSerializer
from rest_framework.permissions import IsAuthenticated

class BookListView(generics.ListAPIView):
    serializer_class = BookSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        
        # If the user is an admin, return all books
        if user.role == 'admin':
            return Book.objects.all()
        
        # For non-admin users, filter books by the user's region
        return Book.objects.filter(region=user.region)