from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from django.utils.translation import gettext_lazy as _
from django.utils.html import format_html
from .models import BlacklistedToken

# Get the custom user model
CustomUser = get_user_model()

class CustomUserChangeForm(UserChangeForm):
    class Meta(UserChangeForm.Meta):
        model = CustomUser
        fields = '__all__'

class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'password1', 'password2', 'first_name', 'last_name', 'profile_image', 'role', 'region')

class CustomUserAdmin(UserAdmin):
    form = CustomUserChangeForm
    add_form = CustomUserCreationForm
    model = CustomUser
    fieldsets = UserAdmin.fieldsets + (
        (_('Personal info'), {'fields': ('profile_image', 'role', 'region')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password1', 'password2', 'first_name', 'last_name', 'email', 'profile_image', 'role', 'region'),
        }),
    )
    list_display = ['username', 'email', 'first_name', 'last_name', 'role', 'region', 'is_staff', 'prof_image_tag']
    
    def prof_image_tag(self, obj):
        if obj.profile_image:
            return format_html('<img src="{}" alt="Profile image for {}" style="width: 45px; height:45px;"/>', obj.profile_image.url, obj.username)
        return "-"
    prof_image_tag.short_description = 'Profile Image'




class BlacklistedTokenAdmin(admin.ModelAdmin):
    list_display = ('jti', 'created_at')  # Display these fields in the admin list view
    search_fields = ('jti',)  # Allow searching by JTI
    readonly_fields = ('jti', 'created_at')  # Make all fields read-only

# Register your models here.
admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(BlacklistedToken, BlacklistedTokenAdmin)
