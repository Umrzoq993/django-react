from rest_framework import viewsets, status
from rest_framework.response import Response
from .models import Manager, Customer
from .serializers import ManagerSerializer, CustomerSerializer

class ManagerViewSet(viewsets.ModelViewSet):
    queryset = Manager.objects.all()
    serializer_class = ManagerSerializer

    def get_serializer_context(self):
        return {'request': self.request}


class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

    def create(self, request, *args, **kwargs):
        # Check if the image file is being received in the request
        print("Request FILES: ", request.FILES)  # This will log any uploaded files
        print("Request DATA: ", request.data)  # This will log the rest of the form data
        
        # Continue with normal validation and save process
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            # Print or log the error details to debug the issue
            print(serializer.errors)  # Debugging purpose
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

