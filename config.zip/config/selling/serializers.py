from rest_framework import serializers
from .models import Manager, Customer

class SimpleManagerSerializer(serializers.ModelSerializer):
    profile_image = serializers.SerializerMethodField()

    class Meta:
        model = Manager
        fields = ['id', 'name', 'profile_image']

    def get_profile_image(self, obj):
        request = self.context.get('request')
        if obj.profile_image and request:
            return request.build_absolute_uri(obj.profile_image.url)
        return None

class SimpleCustomerSerializer(serializers.ModelSerializer):
    profile_image = serializers.SerializerMethodField()

    class Meta:
        model = Customer
        fields = ['id', 'name', 'profile_image']

    def get_profile_image(self, obj):
        request = self.context.get('request')
        if obj.profile_image and request:
            return request.build_absolute_uri(obj.profile_image.url)
        return None

# Full Manager Serializer with Customer details
class ManagerSerializer(serializers.ModelSerializer):
    customers = serializers.PrimaryKeyRelatedField(many=True, queryset=Customer.objects.all(), required=False)

    class Meta:
        model = Manager
        fields = ['id', 'name', 'profile_image', 'customers']

    def create(self, validated_data):
        # Pop customers from validated_data to handle them manually
        customers = validated_data.pop('customers', [])

        # Create the new manager
        manager = Manager.objects.create(**validated_data)

        # Assign selected customers to the new manager
        manager.customers.set(customers)

        # Also add this manager to the selected customers' manager lists
        for customer in customers:
            customer.managers.add(manager)  # Update the reverse relationship

        return manager



class CustomerSerializer(serializers.ModelSerializer):
    managers = serializers.PrimaryKeyRelatedField(many=True, queryset=Manager.objects.all(), required=False)

    class Meta:
        model = Customer
        fields = ['id', 'name', 'profile_image', 'managers']

    def create(self, validated_data):
        # Pop managers from validated_data to handle them manually
        managers = validated_data.pop('managers', [])

        # Create the new customer
        customer = Customer.objects.create(**validated_data)

        # Assign selected managers to the new customer
        customer.managers.set(managers)

        # Also add this customer to the selected managers' customer lists
        for manager in managers:
            manager.customers.add(customer)  # Update the reverse relationship

        return customer