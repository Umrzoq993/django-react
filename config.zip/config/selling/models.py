from django.db import models

class Manager(models.Model):
    name = models.CharField(max_length=100)
    profile_image = models.ImageField(upload_to='manager_profiles/', null=True, blank=True)
    customers = models.ManyToManyField('Customer', related_name='managers_of', blank=True)

    def __str__(self):
        return self.name

class Customer(models.Model):
    name = models.CharField(max_length=100)
    profile_image = models.ImageField(upload_to='customer_profiles/', null=True, blank=True)
    managers = models.ManyToManyField(Manager, related_name='customers_of', blank=True)

    def __str__(self):
        return self.name
