from django.contrib import admin
from .models import Manager, Customer
from django.utils.html import format_html

class ManagerAdmin(admin.ModelAdmin):
    list_display = ['name', 'prof_image_tag']
    search_fields = ['name']
    
    def prof_image_tag(self, obj):
        if obj.profile_image:
            return format_html('<img src="{}" alt="Profile image for {}" style="width: 45px; height:45px;"/>', obj.profile_image.url, obj.name)
        return "-"

class CustomerAdmin(admin.ModelAdmin):
    list_display = ['name', 'prof_image_tag']
    search_fields = ['name']
    
    def prof_image_tag(self, obj):
        if obj.profile_image:
            return format_html('<img src="{}" alt="Profile image for {}" style="width: 45px; height:45px;"/>', obj.profile_image.url, obj.name)
        return "-"

admin.site.register(Manager, ManagerAdmin)
admin.site.register(Customer, CustomerAdmin)
