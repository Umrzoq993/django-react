from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StrangerViewSet

router = DefaultRouter()
router.register(r'strangers', StrangerViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
