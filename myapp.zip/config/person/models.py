from django.db import models


class Stranger(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    last_seen = models.DateTimeField()


class Phone(models.Model):
    stranger = models.ForeignKey(Stranger, related_name='phones', on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=20)


class Email(models.Model):
    stranger = models.ForeignKey(Stranger, related_name='emails', on_delete=models.CASCADE)
    email_address = models.EmailField()


class Messenger(models.Model):
    stranger = models.ForeignKey(Stranger, related_name='messengers', on_delete=models.CASCADE)
    messenger_id = models.CharField(max_length=100)


class Video(models.Model):
    stranger = models.ForeignKey(Stranger, related_name='videos', on_delete=models.CASCADE)
    video_file = models.FileField(upload_to='videos/')


class Image(models.Model):
    stranger = models.ForeignKey(Stranger, related_name='images', on_delete=models.CASCADE)
    image_file = models.ImageField(upload_to='images/')


class Audio(models.Model):
    stranger = models.ForeignKey(Stranger, related_name='audios', on_delete=models.CASCADE)
    audio_file = models.FileField(upload_to='audios/')
