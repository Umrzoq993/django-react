from rest_framework import viewsets
from .models import Stranger
from .serializers import StrangerSerializer


class StrangerViewSet(viewsets.ModelViewSet):
    queryset = Stranger.objects.all()
    serializer_class = StrangerSerializer

    def post(self, request, *args, **kwargs):
        print(request.data)
        return super().post(request, *args, **kwargs)
