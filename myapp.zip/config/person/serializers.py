from rest_framework import serializers
from .models import Stranger, Phone, Email, Messenger, Video, Image, Audio


class PhoneSerializer(serializers.ModelSerializer):
    class Meta:
        model = Phone
        fields = ['id', 'phone_number']


class EmailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Email
        fields = ['id', 'email_address']


class MessengerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Messenger
        fields = ['id', 'messenger_id']


class VideoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Video
        fields = ['id', 'video_file']


class ImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Image
        fields = ['id', 'image_file']


class AudioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Audio
        fields = ['id', 'audio_file']


class StrangerSerializer(serializers.ModelSerializer):
    phones = PhoneSerializer(many=True)
    emails = EmailSerializer(many=True)
    messengers = MessengerSerializer(many=True)
    videos = VideoSerializer(many=True)
    images = ImageSerializer(many=True)
    audios = AudioSerializer(many=True)

    class Meta:
        model = Stranger
        fields = ['id', 'name', 'age', 'last_seen', 'phones', 'emails', 'messengers', 'videos', 'images', 'audios']

    def create(self, validated_data):
        print(validated_data)
        phones_data = validated_data.pop('phones', [])
        emails_data = validated_data.pop('emails', [])
        messengers_data = validated_data.pop('messengers', [])
        videos_data = validated_data.pop('videos', [])
        images_data = validated_data.pop('images', [])
        audios_data = validated_data.pop('audios', [])

        stranger = Stranger.objects.create(**validated_data)

        for phone_data in phones_data:
            Phone.objects.create(stranger=stranger, **phone_data)
        for email_data in emails_data:
            Email.objects.create(stranger=stranger, **email_data)
        for messenger_data in messengers_data:
            Messenger.objects.create(stranger=stranger, **messenger_data)
        for video_data in videos_data:
            Video.objects.create(stranger=stranger, **video_data)
        for image_data in images_data:
            Image.objects.create(stranger=stranger, **image_data)
        for audio_data in audios_data:
            Audio.objects.create(stranger=stranger, **audio_data)

        return stranger