from django.contrib import admin
from .models import Stranger, Phone, Email, Messenger, Video, Audio, Image


# Register your models here.
class PhoneInline(admin.TabularInline):
    model = Phone
    extra = 1  # specifies how many rows are displayed for entering new related objects


class EmailInline(admin.TabularInline):
    model = Email
    extra = 1


class MessengerInline(admin.TabularInline):
    model = Messenger
    extra = 1


class VideoInline(admin.TabularInline):
    model = Video
    extra = 1


class AudioInline(admin.TabularInline):
    model = Audio
    extra = 1


class ImageInline(admin.TabularInline):
    model = Image
    extra = 1


class StrangerAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'last_seen')  # columns shown in the admin list view
    inlines = [PhoneInline, EmailInline, MessengerInline, VideoInline, AudioInline, ImageInline]


admin.site.register(Stranger, StrangerAdmin)
