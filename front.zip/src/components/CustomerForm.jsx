import React, { useState, useEffect } from "react";
import axios from "axios";

const CustomerForm = () => {
  const [name, setName] = useState("");
  const [profileImage, setProfileImage] = useState(null);
  const [managers, setManagers] = useState([]);
  const [selectedManagers, setSelectedManagers] = useState([]);

  // Fetch the list of managers for selection
  useEffect(() => {
    axios
      .get("http://localhost:8000/selling/managers/")
      .then((response) => {
        setManagers(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the managers!", error);
      });
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("name", name);

    // Check if a profile image is selected and append it to the formData
    if (profileImage) formData.append("profile_image", profileImage);

    selectedManagers.forEach((managerId) => {
      formData.append("managers", managerId);
    });

    axios
      .post("http://localhost:8000/selling/customers/", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((response) => {
        console.log("Customer created:", response.data);
      })
      .catch((error) => {
        if (error.response) {
          console.error("Error response data:", error.response.data);
        } else if (error.request) {
          console.error("Error request data:", error.request);
        } else {
          console.error("Error", error.message);
        }
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name:</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div>
        <label>Profile Image:</label>
        <input
          type="file"
          onChange={(e) => setProfileImage(e.target.files[0])}
        />
      </div>
      <div>
        <label>Select Managers:</label>
        <select
          multiple
          value={selectedManagers}
          onChange={(e) =>
            setSelectedManagers(
              [...e.target.selectedOptions].map((o) => parseInt(o.value))
            )
          }
        >
          {managers.map((manager) => (
            <option key={manager.id} value={manager.id}>
              {manager.name}
            </option>
          ))}
        </select>
      </div>
      <button type="submit">Add Customer</button>
    </form>
  );
};

export default CustomerForm;
