import React, { useState, useEffect } from "react";
import axios from "axios";

const ManagerForm = () => {
  const [name, setName] = useState("");
  const [profileImage, setProfileImage] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [selectedCustomers, setSelectedCustomers] = useState([]);

  // Fetch the list of customers for selection
  useEffect(() => {
    axios
      .get("http://localhost:8000/selling/customers/")
      .then((response) => {
        setCustomers(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the customers!", error);
      });
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("name", name);
    if (profileImage) formData.append("profile_image", profileImage);
    formData.append("customers", selectedCustomers); // Send selected customer IDs

    axios
      .post("http://localhost:8000/selling/managers/", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((response) => {
        console.log("Manager created:", response.data);
      })
      .catch((error) => {
        console.error("Error creating manager:", error);
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name:</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div>
        <label>Profile Image:</label>
        <input
          type="file"
          onChange={(e) => setProfileImage(e.target.files[0])}
        />
      </div>
      <div>
        <label>Select Customers:</label>
        <select
          multiple
          value={selectedCustomers}
          onChange={(e) =>
            setSelectedCustomers(
              [...e.target.selectedOptions].map((o) => o.value)
            )
          }
        >
          {customers.map((customer) => (
            <option key={customer.id} value={customer.id}>
              {customer.name}
            </option>
          ))}
        </select>
      </div>
      <button type="submit">Add Manager</button>
    </form>
  );
};

export default ManagerForm;
