import React, { useState, useEffect } from "react";
import { getCustomers } from "../services/api";

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    getCustomers()
      .then((response) => {
        setCustomers(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the customers!", error);
      });
  }, []);

  return (
    <div>
      <h2>Customers List</h2>
      <ul>
        {customers.map((customer) => (
          <li key={customer.id}>
            <h3>{customer.name}</h3>
            <img
              src={customer.profile_image}
              alt={customer.name}
              style={{ width: "100px" }}
            />
            <p>Managers:</p>
            <ul>
              {customer.managers.map((manager) => (
                <li key={manager.id}>
                  {manager.name} -{" "}
                  <img
                    src={manager.profile_image}
                    alt={manager.name}
                    style={{ width: "50px" }}
                  />
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CustomerList;
