import React, { useState, useEffect } from "react";
import { getManagers } from "../services/api";

const ManagerList = () => {
  const [managers, setManagers] = useState([]);

  useEffect(() => {
    getManagers()
      .then((response) => {
        setManagers(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the managers!", error);
      });
  }, []);

  return (
    <div>
      <h2>Managers List</h2>
      <ul>
        {managers.map((manager) => (
          <li key={manager.id}>
            <h3>{manager.name}</h3>
            <img
              src={manager.profile_image}
              alt={manager.name}
              style={{ width: "100px" }}
            />
            <p>Customers:</p>
            <ul>
              {manager.customers.map((customer) => (
                <li key={customer.id}>
                  {customer.name} -{" "}
                  <img
                    src={customer.profile_image}
                    alt={customer.name}
                    style={{ width: "50px" }}
                  />
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ManagerList;
