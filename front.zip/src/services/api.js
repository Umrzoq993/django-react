import axios from "axios";

// Set your Django backend API base URL here
const API_URL = "http://localhost:8000/selling/";

export const getCustomers = () => {
  return axios.get(`${API_URL}customers/`);
};

export const getManagers = () => {
  return axios.get(`${API_URL}managers/`);
};
