import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import CustomerList from "./components/CustomerList";
import ManagerList from "./components/ManagerList";
import CustomerForm from "./components/CustomerForm";
import ManagerForm from "./components/ManagerForm";

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <a href="/customers">Customers</a>
            </li>
            <li>
              <a href="/managers">Managers</a>
            </li>
            <li>
              <a href="/add-customer">Add Customer</a>
            </li>
            <li>
              <a href="/add-manager">Add Manager</a>
            </li>
          </ul>
        </nav>

        <Routes>
          <Route path="/customers" element={<CustomerList />} />
          <Route path="/managers" element={<ManagerList />} />
          <Route path="/add-customer" element={<CustomerForm />} />
          <Route path="/add-manager" element={<ManagerForm />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
