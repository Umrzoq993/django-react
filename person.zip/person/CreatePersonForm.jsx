// CreatePersonForm.jsx
import React, { useState } from "react";
import axios from "axios";

function CreatePersonForm() {
  const [person, setPerson] = useState({
    name: "",
    age: "",
    email: "",
    phone_numbers: [{ phone_number: "" }],
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPerson((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handlePhoneNumberChange = (index, e) => {
    const newPhoneNumbers = person.phone_numbers.map((phoneNumber, sidx) => {
      if (index === sidx) {
        return { ...phoneNumber, phone_number: e.target.value };
      }
      return phoneNumber;
    });

    setPerson((prevState) => ({
      ...prevState,
      phone_numbers: newPhoneNumbers,
    }));
  };

  const addPhoneNumber = () => {
    setPerson((prevState) => ({
      ...prevState,
      phone_numbers: [...prevState.phone_numbers, { phone_number: "" }],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("name", person.name);
    formData.append("age", person.age);
    formData.append("email", person.email);

    person.phone_numbers.forEach((phoneNumber, index) => {
      formData.append(
        `phone_numbers[${index}][phone_number]`,
        phoneNumber.phone_number
      );
    });

    try {
      const response = await axios.post(
        "http://localhost:8000/api/persons/",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log("Server Response:", response.data);
    } catch (error) {
      console.error("Submission Error:", error.response);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>Name:</label>
      <input
        type="text"
        name="name"
        value={person.name}
        onChange={handleInputChange}
      />

      <label>Age:</label>
      <input
        type="number"
        name="age"
        value={person.age}
        onChange={handleInputChange}
      />

      <label>Email:</label>
      <input
        type="email"
        name="email"
        value={person.email}
        onChange={handleInputChange}
      />

      {person.phone_numbers.map((phoneNumber, index) => (
        <div key={index}>
          <label>Phone Number {index + 1}:</label>
          <input
            type="text"
            value={phoneNumber.phone_number}
            onChange={(e) => handlePhoneNumberChange(index, e)}
          />
        </div>
      ))}

      <button type="button" onClick={addPhoneNumber}>
        Add Phone Number
      </button>
      <button type="submit">Submit</button>
    </form>
  );
}

export default CreatePersonForm;
