import React, { useState } from "react";
import axios from "axios";

function CreatePersonForm() {
  const [person, setPerson] = useState({
    name: "",
    age: "",
    email: "",
    phone_numbers: [{ phone_number: "" }], // Ensure this matches your Django model's expected input
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPerson((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePhoneNumberChange = (index, e) => {
    const newPhoneNumbers = person.phone_numbers.map((item, sidx) => {
      if (index === sidx) {
        return { ...item, phone_number: e.target.value };
      }
      return item;
    });

    setPerson((prev) => ({
      ...prev,
      phone_numbers: newPhoneNumbers,
    }));
  };

  const addPhoneNumber = () => {
    setPerson((prev) => ({
      ...prev,
      phone_numbers: [...prev.phone_numbers, { phone_number: "" }],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:8000/api/persons/",
        JSON.stringify(person),
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log(response.data);
    } catch (error) {
      console.error("There was an error!", error);
      console.log(error.response.data); // Detailed error from the server
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>Name:</label>
      <input
        type="text"
        name="name"
        value={person.name}
        onChange={handleInputChange}
      />

      <label>Age:</label>
      <input
        type="number"
        name="age"
        value={person.age}
        onChange={handleInputChange}
      />

      <label>Email:</label>
      <input
        type="email"
        name="email"
        value={person.email}
        onChange={handleInputChange}
      />

      {person.phone_numbers.map((phoneNumber, index) => (
        <div key={index}>
          <label>Phone Number {index + 1}:</label>
          <input
            type="text"
            value={phoneNumber.phone_number}
            onChange={(e) => handlePhoneNumberChange(index, e)}
          />
        </div>
      ))}

      <button type="button" onClick={addPhoneNumber}>
        Add Phone Number
      </button>

      <button type="submit">Submit</button>
    </form>
  );
}

export default CreatePersonForm;
