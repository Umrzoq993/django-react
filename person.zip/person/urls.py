# persons/urls.py

from django.urls import path
from .views import PersonAPIView

urlpatterns = [
    path('persons/', PersonAPIView.as_view(), name='create_person'),  # Route for creating a person
]
