from django.contrib import admin
from .models import Person, PhoneNumber


class PhoneNumberInline(admin.TabularInline):
    model = PhoneNumber
    extra = 1  # Specifies the number of extra forms to display


class PersonAdmin(admin.ModelAdmin):
    inlines = [PhoneNumberInline]
    list_display = ('name', 'age', 'email')  # Adjust fields to display as needed
    search_fields = ('name', 'email')  # Enables search by name and email


admin.site.register(Person, PersonAdmin)
