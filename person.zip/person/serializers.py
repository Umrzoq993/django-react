from rest_framework import serializers
from .models import Person, PhoneNumber


class PhoneNumberSerializer(serializers.ModelSerializer):
    class Meta:
        model = PhoneNumber
        fields = ['phone_number']


class PersonSerializer(serializers.ModelSerializer):
    phone_numbers = PhoneNumberSerializer(many=True)

    class Meta:
        model = Person
        fields = ['id', 'name', 'age', 'email', 'phone_numbers']

    def create(self, validated_data):
        phone_numbers_data = validated_data.pop('phone_numbers', None)
        person = Person.objects.create(**validated_data)
        if phone_numbers_data:
            for phone_data in phone_numbers_data:
                PhoneNumber.objects.create(person=person, **phone_data)
        return person
