# views.py
from django.http import JsonResponse
from rest_framework.views import APIView
from .models import Person, PhoneNumber
from rest_framework.response import Response
from .serializers import PersonSerializer
from rest_framework.parsers import MultiPartParser, FormParser


class PersonAPIView(APIView):
    parser_classes = [MultiPartParser, FormParser]

    def get(self, request, *args, **kwargs):
        persons = Person.objects.all()
        serializer = PersonSerializer(persons, many=True)
        return Response(serializer.data)

    def post(self, request, *args, **kwargs):
        name = request.data.get('name')
        age = request.data.get('age')
        email = request.data.get('email')

        person = Person.objects.create(name=name, age=age, email=email)

        # This loop assumes phone_numbers are submitted with keys like 'phone_numbers[0][phone_number]'
        phone_numbers = []
        for key, value in request.data.items():
            if key.startswith('phone_numbers'):
                # Extract index and field using a regex if necessary or split method
                _, idx, field = key.split('[')
                idx = int(idx.rstrip(']'))
                field = field.rstrip(']').split(']')[0]

                # Ensure the phone number list is large enough
                if len(phone_numbers) <= idx:
                    phone_numbers.extend([None] * (idx + 1 - len(phone_numbers)))

                # Create a new phone number dictionary if necessary
                if phone_numbers[idx] is None:
                    phone_numbers[idx] = {}

                phone_numbers[idx][field] = value

        # Create PhoneNumber objects
        for phone_data in phone_numbers:
            if phone_data and 'phone_number' in phone_data:
                PhoneNumber.objects.create(person=person, phone_number=phone_data['phone_number'])

        return JsonResponse({'status': 'success', 'id': person.id})

