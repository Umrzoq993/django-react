from rest_framework import serializers
from .models import Stranger, Person

class StrangerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Stranger
        fields = ['id', 'full_name', 'photo', 'persons']

class PersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Person
        fields = ['id', 'full_name', 'photo', 'strangers']
