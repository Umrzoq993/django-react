from django.urls import path
from .views import StrangerList, PersonList

urlpatterns = [
    path('strangers/', StrangerList.as_view(), name='stranger-list'),
    path('persons/', PersonList.as_view(), name='person-list'),
]
