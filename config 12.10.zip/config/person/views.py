from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Stranger, Person
from .serializers import StrangerSerializer, PersonSerializer
from django.db import connection
from django.db import transaction

def custom_sql_stranger(stranger_id, person_id):
    with connection.cursor() as cursor:
        cursor.execute("INSERT INTO person_person_strangers(person_id, stranger_id) VALUES(%s, %s)", [person_id, stranger_id])
        

def custom_sql_person(person_id, stranger_id):
    with connection.cursor() as cursor:
        cursor.execute("INSERT INTO person_stranger_persons(stranger_id, person_id) VALUES(%s, %s)", [stranger_id, person_id])

class StrangerList(APIView):
    def get(self, request, format=None):
        strangers = Stranger.objects.all()
        serializer = StrangerSerializer(strangers, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = StrangerSerializer(data=request.data)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    stranger = serializer.save()
                    person_ids = request.data.get('persons', [])
                    if person_ids:
                        for id in person_ids:
                            custom_sql_stranger(stranger_id=stranger.id, person_id=id)
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class PersonList(APIView):
    def get(self, request, format=None):
        persons = Person.objects.all()
        serializer = PersonSerializer(persons, many=True)
        return Response(serializer.data)
    
    
    def post(self, request, format=None):
        serializer = PersonSerializer(data=request.data)
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    person = serializer.save()
                    stranger_ids = request.data.get('strangers', [])
                    if stranger_ids:
                        for id in stranger_ids:
                            custom_sql_stranger(stranger_id=id, person_id=person.id)
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
