from django.db import models

# Create your models here.
class Stranger(models.Model):
    full_name = models.CharField(max_length=100)
    photo = models.ImageField(upload_to='stranger_photos/', null=True, blank=True)
    persons = models.ManyToManyField('Person', related_name='persons', blank=True)
    
    def __str__(self):
        return self.full_name

    
class Person(models.Model):
    full_name = models.CharField(max_length=100)
    photo = models.ImageField(upload_to='persons_photo/', null=True, blank=True)
    strangers = models.ManyToManyField(Stranger, related_name='strangers', blank=True)
    
    def __str__(self):
        return self.full_name