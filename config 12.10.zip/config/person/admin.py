from django.contrib import admin
from .models import Stranger, Person
from django.utils.html import format_html

class StrangerAdmin(admin.ModelAdmin):
    list_display = ['id', 'full_name', 'photo_tag']
    search_fields = ['full_name']
    list_filter = ['full_name']
    ordering = ['full_name']
    
    def photo_tag(self, obj):
        if obj.photo:
            return format_html('<img src="{}" style="width: 50px; height: 50px;" alt="Photo" />', obj.photo.url)
        return "No Photo"
    
class PersonAdmin(admin.ModelAdmin):
    list_display = ['id', 'full_name', 'photo_tag']
    search_fields = ['full_name']
    list_filter = ['full_name']
    ordering = ['full_name']
    
    def photo_tag(self, obj):
        if obj.photo:
            return format_html('<img src="{}" style="width: 50px; height: 50px;" alt="Photo" />', obj.photo.url)
        return "No Photo"

admin.site.register(Stranger, StrangerAdmin)
admin.site.register(Person, PersonAdmin)
