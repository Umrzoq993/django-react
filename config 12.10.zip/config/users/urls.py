from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CustomUserViewSet
from django.urls import path
from .views import RegisterView, LoginView, LogoutView

router = DefaultRouter()
router.register(r'users', CustomUserViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('api/register/', RegisterView.as_view(), name='register'),
    path('api/login/', LoginView.as_view(), name='login'),
    path('api/logout/', LogoutView.as_view(), name='logout'),
]
